SELECT
	CAST(CLIDOC.FILIAL AS VARCHAR(100)),
	'| ',		-- Codigo da Filial
	CASE WHEN CADPOR.DEBITO = 'N' AND CADPOR.CREDITO = 'S' THEN '2' ELSE '1' END,			
	'| ',		-- Tipo do Documento 1 - Receber e 2 - Pagar
	CAST(CASE CLIDOC.CLIENTE WHEN 999999 THEN 1 ELSE COALESCE(CLIDOC.CLIENTE, 1) END AS VARCHAR(100)),			
	'| ',		-- Codigo do Cliente
	COALESCE(CLIDOC.CONTRATO, 0),		
	'| ',		-- Numero do Documento
	COALESCE(CLIDOC.PARCELA, ''),		
	'| ',		-- Numero da Parcela
	CONVERT(VARCHAR(100), CLIDOC.DT_EMISSAO, 103),			
	'| ',		-- Data de Emissao
	CONVERT(VARCHAR(100), CLIDOC.DT_VENCIMENTO, 103),			
	'| ',		-- Data de Vencimento
	CONVERT(VARCHAR(100), CLIDOC.DT_PAGAMENTO, 103),		
	'| ',		-- Data de Baixa
	CONVERT(VARCHAR(100), CLIDOC.DT_PRORROGACAO, 103),			
	'| ',		-- Data de Prorrogacao
	CAST(COALESCE(CLIDOC.VR_PARCELA, 0) AS VARCHAR(100)),			
	'| ',		-- Valor da Parcela
	COALESCE(CLIDOC.VR_JUROS, 0),			
	'| ',		-- Valor de Juros
	COALESCE(CLIDOC.VR_MULTA, 0),			
	'| ',		-- Valor de Multa
	COALESCE(CLIDOC.VR_DESCONTO, 0),			
	'| ',		-- Valor de Desconto
	COALESCE(VR_PAGO, 0) + COALESCE(VR_JUROS, 0) + COALESCE(VR_MULTA, 0) - COALESCE(VR_DESCONTO, 0),			
	'| ',		-- Valor Baixado
	COALESCE(CAST(CLIDOC.NOTA_FISCAL AS VARCHAR(100)), 'NULL'),		
	'| ',		-- Numero da Nota Fiscal ou Cupom Fiscal
	COALESCE(CAST(CLIDOC.FATURA AS VARCHAR(20)), ''),			
	'| ',		-- Numero da Fatura
	CAST(COALESCE(CLIDOC.DUPLICATA, '') AS VARCHAR(20)),			
	'| ',		-- Numero da Duplicat
	REPLACE(REPLACE(COALESCE(CLIDOC.TEXTO, ''), CHAR(13), ''), CHAR(10), ''),			
	'| ',		-- Observacoes
	CLIDOC.ATIVO 
				-- Ativo

FROM CLIDOC 
LEFT JOIN CADPOR ON CADPOR.PORTADOR = CLIDOC.PORTADOR
WHERE CLIDOC.VR_PARCELA > COALESCE(CLIDOC.VR_PAGO, 0) AND CLIDOC.ATIVO = 1