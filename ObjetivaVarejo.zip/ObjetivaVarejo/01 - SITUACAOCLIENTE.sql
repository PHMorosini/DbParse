SELECT
	SITUACAO,					-- Id
	'|',				   
	DESCRICAO,					-- Nome
	'|',				   
	CASE ESPECIAL WHEN 'S' THEN 1 ELSE 0 END,					-- Especial
	'|',				   
	CASE ATU_CADASTRO WHEN 'S' THEN 1 ELSE 0 END,					-- AtualizarCadastro
	'|',				   
	CASE EXIGE_SENHA WHEN 'S' THEN 1 ELSE 0 END,					-- ExigeSenha
	'|',				   
	CASE BLOQUEAR WHEN 'S' THEN 1 ELSE 0 END,					-- Bloquear
	'|',				   
	1					-- Ativo	
FROM CADSIT -- Tabela