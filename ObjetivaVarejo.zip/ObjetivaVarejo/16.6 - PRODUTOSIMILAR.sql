SELECT
	matricula,					-- ProdutoId
	'|',				   
	similar					-- Similarid
FROM estsim -- Tabela