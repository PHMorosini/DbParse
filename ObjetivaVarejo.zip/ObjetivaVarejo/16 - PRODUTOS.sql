SELECT
	CADPRO.ID,
	'|',
	CADPRO.DESCRICAO,
	'|',
	CADPRO.REFERENCIA,
	'|',
	CADPRO.CODIGO_BARRA,
	'|',
	CADPRO.PESOV,
	'|',
	CADPRO.VOLUME,
	'|',
	CASE WHEN CSTICMSID = '060' THEN '0500'
		 WHEN CSTICMSID = '000' THEN '0102'
		 ELSE '0102'
	END,
	'|',
	0 AS MONOFASICO,
	'|',
	0 AS COMBUSTIVEL,
	'|',
	CASE CADPRO.ALTERAR_VALOR
		WHEN 'S' THEN 1
		ELSE '0'
	END AS ALTERAR_VALOR,
	'|',
	CASE CADPRO.UTILIZABALANCA
		WHEN 'S' THEN 1
		ELSE '0'
	END AS PESAVEL,
	'|',
	CADPRO.UNIDADEPRODUTOID,
	'|',
	--CADPRO.CODIGONCM,
	CASE WHEN LEN(LTRIM(RTRIM(COALESCE(CADPRO.CODIGONCM, '')))) > 0
		THEN CADPRO.CODIGONCM
		ELSE '12040090' --0025654582
	END AS NCMFISCALID, /* Em situacoes onde nao existe o NCMFISCALID Relacionado, utilizar esse codigo */
	'|',
	CADPRO.CESTFISCALID,
	'|',
	CADPRO.ANPFISCALID,
	'|',	
	ESTGRU.DESCRICAO,
	'|',
	CADPRO.MARCA,
	'|',
	CADPRO.GENEROFISCALID,
	'|',
	CADPRO.EXTIPIFISCALID,
	'|',
	CADPRO.ATIVO,
	'|',
	CASE CADPRO.EDITAR
		WHEN 'S' THEN 1
		ELSE '0'
	END AS ALTERADESCRICAO,			--alteradescricaosaida,
	'|',
	CADPRO.aplicacao,			--aplicacao,
	'|',
	(SELECT MAX(PROMOCAOQTDV) FROM ESTSAL WHERE ESTSAL.MATRICULA = CADPRO.ID  and filial = 1),			--quantidadepromocao
	'|',
	CADPRO.DESCRICAO_NF,			--descricaofiscal
	'|',
	CASE cadpro.tipoitem
    WHEN 0 THEN '0'
    WHEN 1 THEN '1'
    WHEN 4 THEN '4'
    WHEN 7 THEN '7'
    WHEN 8 THEN '8'
    WHEN 99 THEN '99'
    ELSE '0'
END AS TipoItemFiscalDescricao,			--tipoitemfiscal
	'|',
	(select max(fator_basev) from estsal  WHERE ESTSAL.MATRICULA = CADPRO.ID and filial = 1),			--fatorpreco
	'|',
	(select max(fator_baseqtdv) from estsal  WHERE ESTSAL.MATRICULA = CADPRO.ID and filial = 1)				--fatorquantidade	
FROM CADPRO
JOIN ESTGRU ON ESTGRU.ID = CADPRO.GRUPO
WHERE CADPRO.ID > 1

