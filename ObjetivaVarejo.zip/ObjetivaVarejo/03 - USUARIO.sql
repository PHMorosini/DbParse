SELECT
	ID + 2,					-- Id
	'|',				   
	nome,					-- Nome
	'|',				   
	login,					-- Login
	'|',				   
	hora_entrada,					-- Hora Entrada
	'|',				   
	hora_saida,					-- Hora Saida
	'|',				   
	e_mail,					-- E-mail
	'|',				   
	ativo					-- Ativo
FROM CADFUN-- Tabela
WHERE ID NOT IN ('999998','999999')