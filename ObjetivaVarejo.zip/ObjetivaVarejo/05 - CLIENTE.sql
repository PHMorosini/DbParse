SELECT distinct
	PESSOA.ID,
	'|',
	CASE WHEN PESSOA.TIPONATUREZA = 'F' THEN 1
	ELSE 2
	END,
	'|',
	CNPJCPF,
	'|',
	PESSOA.NOME,
	'|',
	CASE 
		WHEN LEN(PESSOA.PSEUDONIMO) < 2 THEN PESSOA.NOME
		WHEN PESSOA.PSEUDONIMO IS NULL THEN PESSOA.NOME
		WHEN PESSOA.PSEUDONIMO = '' THEN PESSOA.NOME
	ELSE PESSOA.PSEUDONIMO
	END,
	'|',
	CONVERT(CHAR(10), PESSOA.DATANASCIMENTO, 103) AS DATANASCIMENTO,
	'|',
	PESSOA.INSCRICAOESTADUAL,
	'|',
	PESSOA.INSCRICAOMUNICIPAL,
	'|',
	REPLACE(REPLACE(REPLACE(COALESCE(PESSOA.OBSERVACAOINTERNA, ''), CHAR(10), ''), CHAR(13), ''), '|', ''),
	'|',
	case when PESSOA.INSCRICAOESTADUAL <> '' and PESSOA.INSCRICAOESTADUAL <> 'ISENTO' then 1
	when PESSOA.INSCRICAOESTADUAL = 'ISENTO' then 2
	when PESSOA.INSCRICAOESTADUAL = '' then 9 else 9 end as contribuinte,		
	'|',
	0 AS PERMITEAPROVEITAMENTOCREDITO,
	'|',
	PESSOA.ATIVO,
	'|',
	COALESCE((SELECT FILIAL FROM CADCLI WHERE CADCLI.CLIENTE = PESSOA.ID),(SELECT TOP 1 ID FROM CADFIL WHERE ATIVO = 1 ORDER BY ID ASC)),
	'|',				   
	coalesce(cadcli.IDENTIDADE,''),					-- Identidade
	'|',				   
	coalesce(CADCLI.ORGAOIDENTIDADE,''), -- Orgao expeditor
	'|',					   
CASE CAST(COALESCE(UFIDENTIDADE, '') AS VARCHAR)
    WHEN 'RO' THEN '11'
    WHEN 'AC' THEN '12'
    WHEN 'AM' THEN '13'
    WHEN 'RR' THEN '14'
    WHEN 'PA' THEN '15'
    WHEN 'AP' THEN '16'
    WHEN 'TO' THEN '17'
    WHEN 'MA' THEN '21'
    WHEN 'PI' THEN '22'
    WHEN 'CE' THEN '23'
    WHEN 'RN' THEN '24'
    WHEN 'PB' THEN '25'
    WHEN 'PE' THEN '26'
    WHEN 'AL' THEN '27'
    WHEN 'SE' THEN '28'
    WHEN 'BA' THEN '29'
    WHEN 'MG' THEN '31'
    WHEN 'ES' THEN '32'
    WHEN 'RJ' THEN '33'
    WHEN 'SP' THEN '35'
    WHEN 'PR' THEN '41'
    WHEN 'SC' THEN '42'
    WHEN 'RS' THEN '43'
    WHEN 'MS' THEN '50'
    WHEN 'MT' THEN '51'
    WHEN 'GO' THEN '52'
    WHEN 'DF' THEN '53'
    WHEN 'EX' THEN '99'
    ELSE ''
END AS id_estado,	-- UF identidade
	'|',				   
	coalesce(CONVERT(VARCHAR(10), dtabertura, 103),''),	-- Data Abertura	
	'|',				   
	coalesce(pai,''),					-- Pai
	'|',				   
	coalesce(mae,''),					-- Mae
	'|',				   
	coalesce(natural,''),					-- Naturalidade	
	'|',				   
	CASE CAST(sexo AS varchar)
  WHEN 'M' THEN 1
  WHEN 'F' THEN 2
  WHEN 'O' THEN 3
  ELSE NULL
END,					-- Sexo
	'|',		   
	COALESCE(LIMITE_CREDITO,'0'),					-- Limite credito
	'|',				   
	COALESCE(LIMITE_DEBITO,'0'),					-- Limite debito	
	'|',				   
	COALESCE(vencimento,'0'),					-- Dias para vencimento
	'|',				   
	COALESCE(DESC_MATERIAL,'0'),				-- Desconto para produto
	'|',				   
	COALESCE(DESC_SERVICO,'0'),					-- Desconto para serviço	
	'|',				   
	COALESCE(vr_mensal,'0'),					-- Valor mensal
	'|',					   
	   CASE ESTADOCIVIL WHEN 'O' THEN 5
   WHEN 'S' THEN 1
   WHEN 'C' THEN 2
   WHEN 'P' THEN 5
   WHEN 'D' THEN 3
   WHEN 'V' THEN 4
   ELSE 5 END,					-- Estado civil
	'|',				   
	COALESCE(situacao,1),					-- Situacaoid	
	'|',				   
	coalesce(CONVERT(VARCHAR(10), dtsituacao, 103),''),					-- Datasituacao
	'|',				   
	case coalesce(cast(vendedor as varchar),'') when '0' then '' else coalesce(cast(vendedor + 2 as varchar),'') end,					-- VendedorID
	'|',				   
	COALESCE(tipo,''),					-- TipoclienteId	
	'|',				   
	COALESCE(grade,''),					-- ComplementoGrade
	'|'	,				   
	coalesce(alerta,''),				-- Alerta	
	'|'	,	
	case cast(tipovencimento as varchar) when '0' then '1'
	when '1' then '2'
	else '0' end as tipovencimento
FROM PESSOA
LEFT JOIN CONTRIBUINTE ON CONTRIBUINTE.ID = PESSOA.CONTRIBUINTEID
left join CADCLI on CADCLI.NOME = PESSOA.NOME
WHERE PESSOA.ID < 999999


