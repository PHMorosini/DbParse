SELECT
	CAST(FORDOC.FILIAL AS VARCHAR(100)),
	'| ',		-- Codigo da Filial
	CASE WHEN CADPOR.DEBITO = 'N' AND CADPOR.CREDITO = 'S' THEN '2' ELSE '1' END,			
	'| ',		-- Tipo do Documento 1 - Receber e 2 - Pagar
	FORDOC.FORNECEDOR ,			
	'| ',		-- Codigo do Cliente
	COALESCE(FORDOC.DOCUMENTO, 0),		
	'| ',		-- Numero do Documento
	COALESCE(FORDOC.PARCELA, ''),		
	'| ',		-- Numero da Parcela
	CONVERT(VARCHAR(100), FORDOC.DT_EMISSAO, 103),			
	'| ',		-- Data de Emissao
	CONVERT(VARCHAR(100), FORDOC.DT_VENCIMENTO, 103),			
	'| ',		-- Data de Vencimento
	CONVERT(VARCHAR(100), FORDOC.DT_PAGAMENTO, 103),		
	'| ',		-- Data de Baixa
	CONVERT(VARCHAR(100), FORDOC.DT_PRORROGACAO, 103),			
	'| ',		-- Data de Prorrogacao
	CAST(COALESCE(FORDOC.VR_PARCELA, 0) AS VARCHAR(100)),			
	'| ',		-- Valor da Parcela
	COALESCE(FORDOC.VR_JUROS, 0),			
	'| ',		-- Valor de Juros
	COALESCE(FORDOC.VR_MULTA, 0),			
	'| ',		-- Valor de Multa
	COALESCE(FORDOC.VR_DESCONTO, 0),			
	'| ',		-- Valor de Desconto
	COALESCE(VR_PAGO, 0) + COALESCE(VR_JUROS, 0) + COALESCE(VR_MULTA, 0) - COALESCE(VR_DESCONTO, 0),			
	'| ',		-- Valor Baixado
	COALESCE(CAST(FORDOC.NOTA_FISCAL AS VARCHAR(100)), 'NULL'),		
	'| ',		-- Numero da Nota Fiscal ou Cupom Fiscal
	'',			
	'| ',		-- Numero da Fatura
	CAST(COALESCE(FORDOC.DUPLICATA, '') AS VARCHAR(20)),			
	'| ',		-- Numero da Duplicat
	REPLACE(REPLACE(COALESCE(FORDOC.TEXTO, ''), CHAR(13), ''), CHAR(10), ''),			
	'| ',		-- Observacoes
	CASE COALESCE(FORDOC.USU_EXC, 0) WHEN 0 THEN 1 ELSE 0 END
				-- Ativo

FROM FORDOC 
LEFT JOIN CADPOR ON CADPOR.PORTADOR = FORDOC.PORTADOR
WHERE FORDOC.VR_PARCELA > COALESCE(FORDOC.VR_PAGO, 0) AND CASE COALESCE(FORDOC.USU_EXC, 0) WHEN 0 THEN 1 ELSE 0 END = 1