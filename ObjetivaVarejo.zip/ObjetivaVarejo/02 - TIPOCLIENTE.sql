SELECT
	CODIGO,					-- Id
	'|',				   
	DESCRICAO				-- Descricao				   
FROM TABELA 
WHERE TIPO = 'CADCLI.TIPO' 