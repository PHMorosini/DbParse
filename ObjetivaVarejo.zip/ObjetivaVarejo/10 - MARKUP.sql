SELECT
	ROW_NUMBER() OVER(ORDER BY DATA) + 1, /* Markup 1 ja existe no banco da web. O script 11.1 PRECOS PRODUTOS utiliza a mesma lógica desse arquivo para configurar o Markup */
	'|',
	CADMKP.NOME,
	'|',
	CADMKP.PERCENTUAL,
	'|',
	CADMKP.ATIVO
FROM CADMKP