SELECT
	id,					-- ClienteId
	'|',				   
	2,					-- Tipo
	'|',				   
	nome,					-- Nome
	'|',				   
	coalesce(CONVERT(VARCHAR(10), datanascimento, 103),''),					-- DataNascimento
	'|',			   
	''					-- Observacao
FROM PESSOACONJUGE-- Tabela
where nome <> '' and nome is not null

union all

SELECT
	pessoaid,					-- ClienteId
	'|',				   
	3,					-- Tipo
	'|',				   
	nome,					-- Nome
	'|',				   
	coalesce(CONVERT(VARCHAR(10), datanascimento, 103),''),					-- DataNascimento
	'|',				   
	''					-- Observacao
FROM PESSOADEPENDENTE-- Tabela
where pessoaid is not null and nome <> '' and nome is not null
