SELECT
	matricula,					-- ProdutoId
	'|',				   
	LOCALIZACAOPRODUTOid 					-- Nome Localizacao
from ESTSAL_LOCALIZACAOPRODUTO -- Tabela
left join estsal on estsal.id = ESTSAL_LOCALIZACAOPRODUTO.estsalid