SELECT
	matricula,					-- ProdutoId
	'|',				   
	montadora					-- MontadoraId
FROM estmon-- Tabela